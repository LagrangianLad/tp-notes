class Triangulo:
    pass