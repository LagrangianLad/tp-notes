class Cuadrado:
    pass