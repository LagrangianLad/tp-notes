class Circulo:
    pass